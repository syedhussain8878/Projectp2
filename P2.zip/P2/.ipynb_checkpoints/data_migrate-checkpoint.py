from azure.storage.blob import BlobServiceClient
from azure.cognitiveservices.vision.customvision.training import CustomVisionTrainingClient
from msrest.authentication import ApiKeyCredentials
import os

# Azure Storage Account
STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=azprojectstorage;AccountKey=31RmGSM3VnB1dAgWKCaiz0sVke2ey07Hqb0Hh5CGsC5auUS0VNixZZVp19eMA4B2d4r7BtyEngmr+AStKjmy+A==;EndpointSuffix=core.windows.net"
CONTAINER_NAME = "trafficimages"

# Azure Custom Vision Credentials
ENDPOINT = "https://project1revature.cognitiveservices.azure.com/"
TRAINING_KEY = "ab18fee7fb244940b099ab5a47fd95d1"
PROJECT_ID = "be693a8d-de6b-47ec-b2f9-0ff6baa8a938"

# Initialize Blob Storage Client
blob_service_client = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
container_client = blob_service_client.get_container_client(CONTAINER_NAME)

# Initialize Custom Vision Client
credentials = ApiKeyCredentials(in_headers={"Training-key": TRAINING_KEY})
trainer = CustomVisionTrainingClient(ENDPOINT, credentials)

def upload_images_to_custom_vision(folder_name):
    # List blobs in the folder
    blobs = container_client.list_blobs(name_starts_with=folder_name)

    # Track how many images are uploaded per folder
    image_count = 0
    for blob in blobs:
        # Break if more than 1000 images are processed for the folder
        if image_count >= 1000:
            break

        # Download the blob to local
        blob_client = container_client.get_blob_client(blob)
        blob_data = blob_client.download_blob().readall()
        
        # Save blob locally
        image_path = f"temp_image_{image_count}.jpg"
        with open(image_path, "wb") as f:
            f.write(blob_data)

        # Upload to Custom Vision
        with open(image_path, "rb") as image_data:
            trainer.create_images_from_data(PROJECT_ID, image_data.read())

        # Delete the local image file
        os.remove(image_path)

        image_count += 1
        print(f"Uploaded {image_count} images from folder {folder_name}")

def migrate_images():
    # List all folders (prefixes in blob storage)
    folders = set()
    blobs = container_client.list_blobs()
    for blob in blobs:
        folder_name = blob.name.split('/')[0]
        folders.add(folder_name)

    # Process each folder
    for folder in folders:
        print(f"Processing folder: {folder}")
        upload_images_to_custom_vision(folder)

if __name__ == "__main__":
    migrate_images()
