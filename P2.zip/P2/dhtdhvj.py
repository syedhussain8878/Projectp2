import os

IMAGE_PATH = r"D:\hussa\OriginalTrafficSignData\OriginalTrafficSignData\No entry\augmented_image_11018.jpg"
print(f"Does the file exist? {os.path.exists(IMAGE_PATH)}")
