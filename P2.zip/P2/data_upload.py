from azure.storage.blob import BlobServiceClient
from azure.cognitiveservices.vision.customvision.training import CustomVisionTrainingClient
from azure.cognitiveservices.vision.customvision.training.models import ImageUrlCreateBatch
from azure.cognitiveservices.vision.customvision.training.models import Tag
from msrest.authentication import ApiKeyCredentials
import os
import random

# Azure Blob Storage credentials
blob_connection_string = "DefaultEndpointsProtocol=https;AccountName=azprojectstorage;AccountKey=31RmGSM3VnB1dAgWKCaiz0sVke2ey07Hqb0Hh5CGsC5auUS0VNixZZVp19eMA4B2d4r7BtyEngmr+AStKjmy+A==;EndpointSuffix=core.windows.net"
container_name = "trafficimages"
blob_service_client = BlobServiceClient.from_connection_string(blob_connection_string)
container_client = blob_service_client.get_container_client(container_name)

# Custom Vision credentials
training_key = "ab18fee7fb244940b099ab5a47fd95d1"
training_endpoint = "https://project1revature.cognitiveservices.azure.com/"
project_id = "be693a8d-de6b-47ec-b2f9-0ff6baa8a938"

# Initialize Custom Vision client
credentials = ApiKeyCredentials(in_headers={"Prediction-key": training_key})
training_client = CustomVisionTrainingClient(training_endpoint, credentials)

def get_blobs_from_container(container_client, prefix):
    blobs = container_client.list_blobs(name_starts_with=prefix)
    return [blob.name for blob in blobs]

def upload_images_to_custom_vision(training_client, project_id, tag_names, blob_list):
    # Create tags in Custom Vision
    tags = [training_client.create_tag(project_id, tag_name) for tag_name in tag_names]
    tag_dict = {tag.name: tag.id for tag in tags}
    
    # Randomly select 100 images
    selected_blobs = random.sample(blob_list, min(100, len(blob_list)))
    
    # Upload images
    for blob_name in selected_blobs:
        blob_client = container_client.get_blob_client(blob_name)
        blob_data = blob_client.download_blob().readall()
        
        # Determine the tag for the image
        tag_name = blob_name.split('/')[1]
        tag_id = tag_dict.get(tag_name)
        
        if tag_id:
            print(f"Uploading {blob_name} with tag {tag_name}")
            training_client.create_images_from_data(project_id, image_data=blob_data, tag_ids=[tag_id])

def main():
    subfolder_names = [f.name for f in container_client.list_blobs() if f.name.count('/') == 1]
    
    for subfolder_name in subfolder_names:
        blob_list = get_blobs_from_container(container_client, subfolder_name)
        upload_images_to_custom_vision(training_client, project_id, [subfolder_name], blob_list)

if __name__ == "__main__":
    main()
