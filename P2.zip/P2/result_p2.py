import openai
import os

# Set up OpenAI API key
openai.api_key = os.environ.get("1eef70ad3ac740a28d594bdf94cd99e1")

def get_description(query):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that provides descriptions."},
                {"role": "user", "content": f"Please provide a description of: {query}"}
            ],
            max_tokens=150
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        return f"An error occurred: {str(e)}"

def main():
    print("Welcome to the AI Description Service!")
    print("Enter your query, or type 'quit' to exit.")

    while True:
        query = input("\nWhat would you like a description of? ")
        if query.lower() == 'quit':
            print("Thank you for using the AI Description Service. Goodbye!")
            break

        description = get_description(query)
        print(f"\nDescription: {description}")
if __name__ == "__main__":
    main()