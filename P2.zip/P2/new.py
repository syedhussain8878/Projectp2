import requests
import openai
from azure.cognitiveservices.speech import SpeechConfig, SpeechSynthesizer
from azure.ai.translation.text import TextTranslationClient
from azure.core.credentials import AzureKeyCredential

# Set your OpenAI API key
OPENAI_API_KEY = "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"

# Set the endpoint and model for OpenAI
OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
MODEL_NAME = "gpt-3.5-turbo"  # You can use a free model

# Function to generate detailed description using OpenAI
def generate_openai_description(sign_name):
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": MODEL_NAME,
        "prompt": f"Provide a detailed description of the traffic sign: {sign_name}",
        "max_tokens": 150
    }

    try:
        response = requests.post(OPENAI_API_URL, headers=headers, json=data)
        response.raise_for_status()  # Raise an exception for HTTP errors
        completion = response.json()
        return completion['choices'][0]['text'].strip()
    except requests.exceptions.RequestException as e:
        print(f"Error with OpenAI API: {e}")
        return "No detailed description available."

# Example usage
if __name__ == "__main__":
    description = generate_openai_description("Stop Sign")
    print(f"Description: {description}")
