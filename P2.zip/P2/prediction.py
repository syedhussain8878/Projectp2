import requests

# Set your Azure Custom Vision prediction endpoint and prediction key
ENDPOINT = "https://eastus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/be693a8d-de6b-47ec-b2f9-0ff6baa8a938/classify/iterations/Iteration1/image"
PREDICTION_KEY = "6b6a780224c34818aec70f5e3dca65cd"

# Replace this with the path to your image
IMAGE_PATH = r"D:\hussa\OriginalTrafficSignData\OriginalTrafficSignData\No entry\augmented_image_11018.jpg"

# Set headers with the prediction key
headers = {
    "Prediction-Key": PREDICTION_KEY,
    "Content-Type": "application/octet-stream"
}

# Open the image file and read it in binary mode
with open(IMAGE_PATH, "rb") as image_file:
    image_data = image_file.read()

# Send the request to the Custom Vision API
response = requests.post(ENDPOINT, headers=headers, data=image_data)

# Check the response status and handle accordingly
if response.status_code == 200:
    predictions = response.json().get('predictions', [])
    
    if predictions:
        print("Predictions:")
        for prediction in predictions:
            tag_name = prediction.get('tagName', 'Unknown')
            probability = prediction.get('probability', 0.0)
            print(f"Tag: {tag_name}, Probability: {probability:.2f}")
    else:
        print("No predictions returned.")
else:
    print(f"Error {response.status_code}: {response.text}")
