import os
import numpy as np
import pandas as pd
from keras.models import load_model
from PIL import Image
from flask import Flask, request, render_template
from azure.cognitiveservices.speech import SpeechConfig, SpeechRecognizer, SpeechSynthesizer
import azure.cognitiveservices.speech as speechsdk
import openai

# Set your Azure and OpenAI credentials
AZURE_SPEECH_KEY = '34d192b1dc534d3b90d2dce4b2720cb9'
AZURE_SPEECH_REGION = 'eastus'
AZURE_CUSTOM_VISION_KEY = 'ab18fee7fb244940b099ab5a47fd95d1'
AZURE_CUSTOM_VISION_ENDPOINT = 'https://project1revature.cognitiveservices.azure.com/'
OPENAI_KEY = '1eef70ad3ac740a28d594bdf94cd99e1'

openai.api_key = OPENAI_KEY

# Load the trained Keras model from the specified path
model_path = r"C:\Users\hussa\Downloads\Projectazure\new_model.h5"
try:
    model = load_model(model_path)
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error loading the model: {e}")

# Load traffic sign classes from dataset
def load_traffic_sign_classes(dataset_path):
    classes = {}
    for folder_name in os.listdir(dataset_path):
        folder_path = os.path.join(dataset_path, folder_name)
        if os.path.isdir(folder_path):
            classes[folder_name] = folder_name
    return classes

dataset_path = r'C:\Users\hussa\Downloads\OriginalTrafficSignData\OriginalTrafficSignData'
classes = load_traffic_sign_classes(dataset_path)

# Initialize Flask application
app = Flask(__name__)

# Text-to-Speech using Azure Speech SDK
def azure_text_to_speech(text):
    try:
        speech_config = SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
        synthesizer = SpeechSynthesizer(speech_config=speech_config)
        synthesizer.speak_text_async(text).get()
        print("Speech synthesis completed.")
    except Exception as e:
        print(f"Error in Text-to-Speech: {e}")

# Speech-to-Text using Azure Speech SDK
def azure_speech_to_text():
    try:
        speech_config = SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
        recognizer = SpeechRecognizer(speech_config=speech_config)
        print("Listening... Please speak.")
        result = recognizer.recognize_once()
        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            print(f"Recognized: {result.text}")
            return result.text
        else:
            print("No speech recognized.")
            return None
    except Exception as e:
        print(f"Error in Speech-to-Text: {e}")
        return None

# OpenAI API to generate detailed description of prediction
def generate_openai_description(input_text):
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=f"Provide a detailed description of the following traffic sign: {input_text}",
            max_tokens=150
        )
        return response.choices[0].text.strip()
    except Exception as e:
        print(f"Error with OpenAI API: {e}")
        return None

# Route to upload image for traffic sign prediction
@app.route('/')
def upload():
    return render_template("file_upload_form.html")

# Route to handle image prediction and results
@app.route('/success', methods=['POST'])
def success():
    if request.method == 'POST':
        input_image = request.files['file']
        image_file_name = input_image.filename

        # Preprocess the image for prediction
        try:
            image = Image.open(input_image)
            image = image.convert('RGB')
            image = image.resize((30, 30))
            image = np.expand_dims(image, axis=0)
            image = np.array(image)

            # Predict the traffic sign using the model
            pred = model.predict(image)[0]
            result = classes[np.argmax(pred)]

            print(f"Prediction: {result}")

            # Generate detailed description using OpenAI
            detailed_description = generate_openai_description(result)
            if detailed_description:
                print(f"OpenAI Description: {detailed_description}")
            else:
                detailed_description = "No detailed description available."

            # Use Azure Text-to-Speech to announce the result
            azure_text_to_speech(f"The detected traffic sign is {result}. {detailed_description}")

            # Return result in the success template
            return render_template("success.html", name=image_file_name, target=result, description=detailed_description)

        except Exception as e:
            print(f"Error during image processing or prediction: {e}")
            return "Error processing the image or generating the prediction."

if __name__ == '__main__':
    app.run(debug=True, port=4200)
